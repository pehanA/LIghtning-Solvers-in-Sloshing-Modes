l=1;
h=2;

P={1/2*l , -1/2*l , -1/2*l-h*1i , 1/2*l-h*1i};%This is a vector of the corners

g = [nan nan nan nan];

[Z_1, ~, A , Z_K_1,n,Np,wc,pol,scl,d,ww] = laplace_5_RR(P, g, 'noplots', 'noarnoldi');

[Z, Zplot, A_1 , Z_K_1, n, Np,wc,pol,scl,d,ww] = laplace_5_RR(P , 'noplots' ,  'noarnoldi'); %The Exact BCs don't matter as long as they are dirichlet BCs

%% Set up the Matrix A and B

B_1 = A_1(1:length(Z_K_1) , :); %Extract only the sampled values of the basis functions on the free surface

size_A = (size(A_1)); 

size_B1 = size(B_1);

B_2 = zeros(size_A(1) -size_B1(1), size_A(2));

B = [B_1 ;  B_2]; 

%% Solve the Generalised Rectangular Eigenvalue problem using a QR Factorisation

[Q_1 , R_1]=qr(A); %The Q_1 here is mxm and R_1 is mxn

[~,n_1]=size(A);

Q = Q_1(:,1:n_1); %The Q here is mxn 

R = R_1(1:n_1,:); %The R here is nxn

C = Q.'*B; 

[V,D] = eig(R,C);

lambda = [];

for j= 1:length(D) %Store the eigenvalues in a single array
        lambda = [lambda D(j,j) ];
end

lambda = lambda(isfinite(lambda));

%% Calculate the error

lambda_a = []; %This array will store the set of analytical eigenvalues

for m = 1:20
    k_m = m.*pi./l;
    lambda_a = [lambda_a k_m.*tanh(k_m.*h)];
end

lambda = lambda(abs(lambda)<50);

distances_1 = [];

for j_1 = 1:length(lambda)
    for j_2 = 1: length(lambda_a)
       distances_1(j_1,j_2) = abs(lambda(j_1) - lambda_a(j_2));
    end
end

[min_distance_1, I] = min(distances_1); 
%This gives us the accuracy for each analytical eigenvalue - the jth entry is the minimum distance b\w all the numerical eigenvalues and the jth analytical eigenvalue 
