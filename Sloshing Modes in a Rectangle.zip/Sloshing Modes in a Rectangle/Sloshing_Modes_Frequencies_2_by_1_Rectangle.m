P = {1, -1, -1-1i , 1-1i}; % Corners for a 2 by 1 rectangle
g = [nan nan nan nan];

%% Obtain the Matrices A and B

[Z_1, ~, A , Z_K_1,n,Np,wc,pol,scl,d,ww] = laplace_5_RR(P, g, 'noplots', 'noarnoldi');

[Z, Zplot, A_1 , Z_K_1, n, Np,wc,pol,scl,d,ww] = laplace_5_RR(P , 'noplots' ,  'noarnoldi'); %The BCs don't matter, we only want dirichlet BCs

B_1 = A_1(1:length(Z_K_1) , :);

size_A = (size(A_1));

size_B1 = size(B_1);

B_2 = zeros(size_A(1) -size_B1(1), size_A(2));

B = [B_1 ;  B_2];

%% Solve the Rectangular Generalised Eigenvalue Problem using the QR Factorisation

[Q_1 , R_1]=qr(A); %The Q_1 here is mxm and R_1 is mxn

[~,n_1]=size(A);

Q = Q_1(:,1:n_1);

R = R_1(1:n_1,:);

C = Q.'*B;

[V,D] = eig(R,C);

lambda = [];

for j= 1:length(D) %Store the eigenvalues in a single array
        lambda = [lambda D(j,j) ];
end

%% Calculate the Absolute Error

lambda = lambda(isfinite(lambda));

L = 2;
h=1;

lambda_a = [];

for m = 1:20
    k_m = m.*pi./L;
    lambda_a = [lambda_a k_m.*tanh(k_m.*h)];
end

lambda = lambda(abs(lambda)<50);

distances_1 = [];

for j_1 = 1:length(lambda)
    for j_2 = 1: length(lambda_a)
       distances_1(j_1,j_2) = abs(lambda(j_1) - lambda_a(j_2));
    end
end

[min_distance_1, I] = min(distances_1); %This gives us the accuracy for each analytical eigenvalue - the jth entry is the minimum distance b\w all the numerical eigenvalues and the jth analytical eigenvalue 
 
lambda_n_1 = lambda(I(1));
lambda_n_2 = lambda(I(2));
lambda_n_3 = lambda(I(3));
lambda_n_4 = lambda(I(4));

%% Obtain the corresponding Eigenvectors

V_0 = null(A-lambda_n_1*B); 
V_1=null(A-lambda_n_2*B);
V_2 = null(A-lambda_n_3*B);
V_3 = null(A-lambda_n_4*B);

c_0 = V_0(:,1);
c_1 = V_1(:,1); 
c_2 = V_2(:,1);
c_3 = V_3(:,1);

function fZ = fzeval(Z,wc,cc,pol,d,scl,n) 
ZZ = [wc; Z];
Q = ((ZZ-wc)/scl).^(0:n);
fZZ = Q*cc; 
fZ = fZZ(2:end) - 1i*imag(fZZ(1));
end

%% Setup Plots

LW = 'linewidth'; MS = 'markersize'; FS = 'fontsize';
fs = 9; PO = 'position'; FW = 'fontweight'; NO = 'normal';

% ww = [1+1i;-1+1i;0;1+1i];
wr = sort(real(ww)); wr = wr([1 end]);
wi = sort(imag(ww)); wi = wi([1 end]);
wc = mean(wr+1i*wi);                            %This is our z_*
scl = max([diff(wr),diff(wi)]);

sx = linspace(wr(1),wr(2),100); sy = linspace(wi(1),wi(2),100);
[xx,yy] = meshgrid(sx,sy); zz = xx + 1i*yy;
ax = [wr(1:2); wi(1:2)] + .2*scl*[-1 1 -1 1]';
axwide = [wr(1:2); wi(1:2)] + 1.1*scl*[-1 1 -1 1]';

inpolygonc = @(z,w) inpolygon(real(z), ...
            imag(z),real(w),imag(w));            % complex variant of "inpolygon"

%% Plot of Fundemental Mode

cc_0 = [c_0(1); c_0(2:n+1)-1i*c_0(n+2:2*n+1)];            % complex coeffs for f_0

f_0 = @(z) reshape(fzeval(z(:),wc,...       % Zeroth Sloshing Mode Function
              cc_0,pol,d,scl,n),size(z));  

u_0 = @(z) imag(f_0(z));                    % Zeroth Sloshing Mode Streamfunction

uu=u_0(zz);
uu_f = abs(uu(~isnan(uu)));
uu_avg = mean(uu_f);

uu_0 = u_0(zz); uu_0(~inpolygonc(zz,ww)) = nan;
uu_0=-uu_0/uu_avg; %Normalisation for the fundemental mode
% uu_0 =uu_0+1;
psi_0 = @(x,y) sin(pi*1*(x+1)/2)*sinh(pi*1*(y+1)/2);
psi_0z=[];
for p=1:100
    for q=1:100
        psi_0z(p,q)=psi_0(real(zz(p,q)), imag(zz(p,q)));
    end
end
psi_0z(~inpolygonc(zz,ww)) = nan;

% subplot(2,1,1)
subplot(3,2,1)


contourf(sx,sy,psi_0z ), colorbar, axis equal, hold on
plot(ww,'-k',LW,1) %This plots the triangle and poles
set(gca,FS,fs-1), axis(ax) 
title('Analytical Fundemental Mode')
hold off

% subplot(2,1,2)
subplot(3,2,2)

levels = [-2,-1.35,-1,-0.5,0,0.5,1,1.5,2,2.5];
contourf(sx,sy,uu_0,levels), colorbar, axis equal, hold on
plot(ww,'-k',LW,1) %This plots the triangle and poles
set(gca,FS,fs-1), axis(ax) 
title('Numerical Fundemental Mode')
hold off

%% Plot of First Mode

cc_1 = [c_1(1); c_1(2:n+1)-1i*c_1(n+2:2*n+1)];              % complex coeffs for f_1

f_1 = @(z) reshape(fzeval(z(:),wc,...       % First Sloshing Mode Function
              cc_1,pol,d,scl,n),size(z));  

u_1 = @(z) imag(f_1(z));                    % First Sloshing Mode Streamfunction

uu=u_1(zz);
uu_f = abs(uu(~isnan(uu)));
uu_avg = mean(uu_f);

uu_1 = u_1(zz); uu_1(~inpolygonc(zz,ww)) = nan;
uu_1=uu_1/uu_avg; %Normalisation for the first mode

psi_1 = @(x,y) sin(pi*2*(x+1)/2)*sinh(pi*2*(y+1)/2);
psi_1z=[];
for p=1:100
    for q=1:100
        psi_1z(p,q)=psi_1(real(zz(p,q)), imag(zz(p,q)));
    end
end
psi_1z(~inpolygonc(zz,ww)) = nan;

% subplot(2,1,1)
subplot(3,2,3)

contourf(sx,sy,psi_1z./2 ), colorbar, axis equal, hold on
plot(ww,'-k',LW,1) %This plots the triangle and poles
set(gca,FS,fs-1), axis(ax) 
title('Analytical First Mode')
hold off

% subplot(2,1,2)
subplot(3,2,4)

levels = [-2,-1.5,-1,-0.5,-0.25,0,0.25,0.5,1,1.5];
contourf(sx,sy,uu_1), colorbar, axis equal, hold on
plot(ww,'-k',LW,1) %This plots the triangle and poles
set(gca,FS,fs-1), axis(ax) 
title('Numerical First Mode')
hold off

%% Plot of Second Mode

cc_2 = [c_2(1); c_2(2:n+1)-1i*c_2(n+2:2*n+1)];            % complex coeffs for f_0

f_2 = @(z) reshape(fzeval(z(:),wc,...       % Zeroth Sloshing Mode Function
              cc_2,pol,d,scl,n),size(z));  

u_2 = @(z) imag(f_2(z));                    % Zeroth Sloshing Mode Streamfunction

uu=u_2(zz);
uu_f = abs(uu(~isnan(uu)));
uu_avg = mean(uu_f);

uu_2 = u_2(zz); uu_2(~inpolygonc(zz,ww)) = nan;
uu_2=-uu_2/uu_avg; %Normalisation for the fundemental mode
% uu_0 =uu_0+1;
psi_2 = @(x,y) sin(pi*3*(x+1)/2)*sinh(pi*3*(y+1)/2);
psi_2z=[];
for p=1:100
    for q=1:100
        psi_2z(p,q)=psi_2(real(zz(p,q)), imag(zz(p,q)));
    end
end
psi_2z(~inpolygonc(zz,ww)) = nan;

% subplot(2,1,1)
subplot(3,2,5)

contourf(sx,sy,psi_2z.*(2/25) ), colorbar, axis equal, hold on
plot(ww,'-k',LW,1) %This plots the triangle and poles
set(gca,FS,fs-1), axis(ax) 
title('Analytical Second Mode')
hold off

% subplot(2,1,2)
subplot(3,2,6)

levels = [-2,-1.35,-1,-0.5,0,0.5,1,1.5,2,2.5];
contourf(sx,sy,uu_2), colorbar, axis equal, hold on
plot(ww,'-k',LW,1) %This plots the triangle and poles
set(gca,FS,fs-1), axis(ax) 
title('Numerical Second Mode')
hold off