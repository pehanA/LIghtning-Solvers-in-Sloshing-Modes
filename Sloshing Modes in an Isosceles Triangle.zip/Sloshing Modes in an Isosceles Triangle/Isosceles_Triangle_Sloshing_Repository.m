P={1+1i,-1+1i,0}; %This is a vector of the corners

g = [nan nan nan];

[Z_1, ~, A , Z_K_1,n,Np,wc,pol,scl,d,ww] = laplace_triangle(P, g, 'noplots');

[Z, Zplot, A_1 , Z_K_1,n, Np,wc,pol,scl,d,ww] = laplace_triangle(P ,'noplots','noarnoldi'); 
%The Exact BCs don't matter as long as they are dirichlet BCs

%% Set up the Matrix A and B

B_1 = A_1(1:length(Z_K_1) , :); 
%Extract only the sampled values of the basis functions on the free surface

size_A = (size(A_1));

size_B1 = size(B_1);

B_2 = zeros(size_A(1) -size_B1(1), size_A(2));

B = [B_1 ;  B_2];

%% Solve the Generalised Rectangular Eigenvalue problem using a QR Factorisation

[Q_1 , R_1]=qr(A); %The Q_1 here is mxm and R_1 is mxn

[~,n_1]=size(A);

Q = Q_1(:,1:n_1);

R = R_1(1:n_1,:);

C = Q.'*B;

[V,D] = eig(R,C);

lambda = [];

for j= 1:length(D) %Store the eigenvalues in a single array
        lambda = [lambda D(j,j) ];
end

%% Generate a list of the analytical eigenvalues (Extracted from Lamb Hydrodynamics (Section 258))

fun = @(x) cos(2*x)*cosh(2*x)-1;
x1=fzero(fun,[2,3]);
lambda_a_1 = x1*(tanh(x1));
x2=fzero(fun,[3.5,4.5]);
lambda_a_2 = x2*(tanh(x2))^(-1);
x3=fzero(fun,[5,6]);
lambda_a_3 = x3*(tanh(x3));
x4=fzero(fun,[6.5,7.5]);
lambda_a_4 = x4*(tanh(x4))^(-1);
x5=fzero(fun,[8,9]);
lambda_a_5 = x5*(tanh(x5));
x6=fzero(fun,[10,11]);
lambda_a_6 = x6*(tanh(x6))^(-1);
x7=fzero(fun,[11,12]);
lambda_a_7 = x7*(tanh(x7));
x8=fzero(fun,[13,14]);
lambda_a_8 = x8*(tanh(x8))^(-1);
x9=fzero(fun,[14.5,15.5]);
lambda_a_9 = x9*(tanh(x9));
x10=fzero(fun,[16,17]);
lambda_a_10 = x10*(tanh(x10))^(-1);
x11=fzero(fun,[17.5,18.5]);
lambda_a_11 = x11*(tanh(x11));
x12=fzero(fun,[19,20]);
lambda_a_12 = x12*(tanh(x12))^(-1);
x13=fzero(fun,[19, 20]);
lambda_a_13 = x13*(tanh(x13));
x14=fzero(fun,[21,22]);
lambda_a_14 = x14*(tanh(x14))^(-1);
x15=fzero(fun,[22, 23]);
lambda_a_15 = x15*(tanh(x15));
x16=fzero(fun,[24,25]);
lambda_a_16 = x16*(tanh(x16))^(-1);
x17=fzero(fun,[25.5, 26.5]);
lambda_a_17 = x17*(tanh(x17));
x18=fzero(fun,[27,28]);
lambda_a_18 = x18*(tanh(x18))^(-1);

lambda_a_0 = 1;

lambda_a = [lambda_a_1 ; lambda_a_2; lambda_a_3; lambda_a_4 ; lambda_a_5 ; lambda_a_6; lambda_a_7 ; lambda_a_8 ; lambda_a_9 ; lambda_a_10 ; lambda_a_11 ; lambda_a_12 ; lambda_a_13 ; lambda_a_14 ; lambda_a_15 ; lambda_a_16; lambda_a_17; lambda_a_18];
%Store the anayltical eigenvalues as a single list.

%% Calculate the error

distances_1 = [];

for j_1 = 1:length(lambda)
    for j_2 = 1: length(lambda_a)
       distances_1(j_1,j_2) = abs(lambda(j_1) - lambda_a(j_2));
    end
end

distance_0=[];

for j=1:length(lambda)
    distance_0(j)=abs(lambda(j)-lambda_a_0);
end

[min_distance_0,I_0] = min(distance_0);

[min_distance_1,I] = min(distances_1); 
%This gives us the accuracy for each analytical eigenvalue - the jth entry is the minimum 
% distance b\w all the numerical eigenvalues and the jth analytical eigenvalue

%% Obtain the corresponding Eigenvectors

lambda_n0=lambda(I_0);
lambda_n1 = lambda(I(1));
lambda_n2 = lambda(I(2));
lambda_n3 = lambda(I(3));
lambda_n4 = lambda(I(4));

V_0 =  null(A-lambda_n0*B);
V_1 =  null(A-lambda_n1*B);
V_2 =  null(A-lambda_n2*B);
V_3 =  null(A-lambda_n3*B);
V_4 =  null(A-lambda_n4*B);

c_0 = V_0(:,1);
c_1 = V_1(:,1);
c_2 = V_2(:,1);

cc = [c_0(1); c_0(2:n+1)-1i*c_0(n+2:2*n+1)];        

function fZ = fzeval(Z,wc,cc,pol,d,scl,n) 
ZZ = [wc; Z];
Q = ((ZZ-wc)/scl).^(0:n);
fZZ = Q*cc; 
fZ = fZZ(2:end) - 1i*imag(fZZ(1)); 
end

%% Setup Plots

LW = 'linewidth'; MS = 'markersize'; FS = 'fontsize';
fs = 9; PO = 'position'; FW = 'fontweight'; NO = 'normal';

% ww = [1+1i;-1+1i;0;1+1i];
wr = sort(real(ww)); wr = wr([1 end]);
wi = sort(imag(ww)); wi = wi([1 end]);
wc = mean(wr+1i*wi);                            %This is our z_*
scl = max([diff(wr),diff(wi)]);

sx = linspace(wr(1),wr(2),100); sy = linspace(wi(1),wi(2),100);
[xx,yy] = meshgrid(sx,sy); zz = xx + 1i*yy;
ax = [wr(1:2); wi(1:2)] + .2*scl*[-1 1 -1 1]';
axwide = [wr(1:2); wi(1:2)] + 1.1*scl*[-1 1 -1 1]';

inpolygonc = @(z,w) inpolygon(real(z), ...
            imag(z),real(w),imag(w));            % complex variant of "inpolygon"

%% Plot of Fundemental Mode

cc_0 = [c_0(1); c_0(2:n+1)-1i*c_0(n+2:2*n+1)]; % complex coeffs for f

f_0 = @(z) reshape(fzeval(z(:),wc,...       % Zeroth Sloshing Mode Function
              cc_0,pol,d,scl,n),size(z));  

u_0 = @(z) imag(f_0(z));                    % Zeroth Sloshing Mode Streamfunction

uu=u_0(zz);
uu_f = abs(uu(~isnan(uu)));
uu_avg = mean(uu_f); 

uu_0 = u_0(zz); uu_0(~inpolygonc(zz,ww)) = nan;
uu_0=uu_0/uu_avg; %Normalisation for the fundemental mode

uu_0 = (uu_0+0.5)/2; 
%Since the governing differential equations are linear, we can multiply any
%solution by a constant. Moreover, the streamfunction is defined up to the
%addition of a constant.

psi_0 = @(x,y) x^2 - y^2; 
%Note that unlike the subsequent higher modes, the fundemental mode is algebraic

psi_0z=[];

for p=1:100
    for q=1:100
        psi_0z(p,q)=psi_0(real(zz(p,q)),imag(zz(p,q)));
    end
end

psi_0z = -psi_0z;
psi_0z(~inpolygonc(zz,ww)) = nan;

subplot(2,1,1)

contourf(sx,sy,psi_0z ), colorbar, axis equal, hold on
plot(ww,'-k',LW,1) %This plots the triangle and poles
set(gca,FS,fs-1), axis(ax) 
title('Analytical Fundemental Mode')
hold off

subplot(2,1,2)
levels = [-0.1,0,0.1,0.2,0.3,0.4,0.5,0.6,0.7,0.8,0.9,1];
contourf(sx,sy,uu_0,levels), colorbar, axis equal, hold on
plot(ww,'-k',LW,1) %This plots the triangle and poles
set(gca,FS,fs-1), axis(ax) 
title('Numerical Fundemental Mode')
hold off

%% Plot of First Mode

% cc_1 = [c_1(1); c_1(2:n+1)-1i*c_1(n+2:2*n+1)];           % complex coeffs for f
% 
% f_1 = @(z) reshape(fzeval(z(:),wc,...       % First Sloshing Mode Function
%               cc_1,pol,d,scl,n),size(z));  
% 
% u_1 = @(z) imag(f_1(z));                    % First Sloshing Mode Streamfunction
% 
% uu=u_1(zz);
% uu_f = abs(uu(~isnan(uu)));
% uu_avg = mean(uu_f); %Normalisation for the first mode
% 
% uu_1 = u_1(zz); uu_1(~inpolygonc(zz,ww)) = nan;
% 
% uu_1 = -uu_1/uu_avg;
% 
% psi_1=@(x,y) sinh(lambda_a_1*x)*sin(lambda_a_1*y)-sin(lambda_a_1*x)*sinh(lambda_a_1*y);
% 
% psi_1z=[];
% 
% for p=1:100
%     for q=1:100
%         psi_1z(p,q)=psi_1(real(zz(p,q)),imag(zz(p,q)));
%     end
% end
% 
% psi_1z(~inpolygonc(zz,ww)) = nan;
% 
% subplot(2,1,1)
% 
% contourf(sx,sy,psi_1z ), colorbar, axis equal, hold on
% plot(ww,'-k',LW,1) %This plots the triangle and poles
% set(gca,FS,fs-1), axis(ax) 
% title('Analytical First Mode')
% hold off
% 
% subplot(2,1,2)
% contourf(sx,sy,uu_1), colorbar, axis equal, hold on
% plot(ww,'-k',LW,1) %This plots the triangle and poles
% set(gca,FS,fs-1), axis(ax) 
% title('Numerical First Mode')
% hold off

%% Plot of Second Mode

% cc_2 = [c_2(1); c_2(2:n+1)-1i*c_2(n+2:2*n+1)];           % complex coeffs for f
% 
% f_2 = @(z) reshape(fzeval(z(:),wc,...                    % Second Sloshing Mode Function
%               cc_2,pol,d,scl,n),size(z));  
% 
% u_2 = @(z) imag(f_2(z));                                 % Second Sloshing Mode Streamfunction
% 
% uu=u_2(zz);
% uu_f = abs(uu(~isnan(uu)));
% uu_avg = mean(uu_f);
% 
% uu_2 = u_2(zz); uu_2(~inpolygonc(zz,ww)) = nan;
% 
% uu_2 = -uu_2/uu_avg;
% 
% psi_2=@(x,y) cosh(lambda_a_2*x)*cos(lambda_a_2*y)-cos(lambda_a_2*x)*cosh(lambda_a_2*y); 
% 
% psi_2z = [];
% 
% for p=1:100
%     for q=1:100
%         psi_2z(p,q)=psi_2(real(zz(p,q)),imag(zz(p,q)));
%     end
% end
% 
% psi_2z(~inpolygonc(zz,ww)) = nan;
% 
% subplot(2,1,1)
% 
% contourf(sx,sy,psi_2z ), colorbar, axis equal, hold on
% plot(ww,'-k',LW,1) %This plots the triangle and poles
% set(gca,FS,fs-1), axis(ax) 
% title('Analytical Second Mode')
% hold off
% 
% subplot(2,1,2)
% contourf(sx,sy,uu_2), colorbar, axis equal, hold on
% plot(ww,'-k',LW,1) %This plots the triangle and poles
% set(gca,FS,fs-1), axis(ax) 
% title('Numerical Second Mode')
% hold off